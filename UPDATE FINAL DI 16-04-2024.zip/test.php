<?php
	$servername="localhost";
	$username="root";
	$password="";
	$db_name="test";
	
	$conn=mysqli_connect($servername,$username,$password,$db_name);
	
	
?>

<!DOCTYPE html>
<html>
<body>
	<?php
	SELECT * FROM `registro` WHERE 1;
	?>
</body>
</html>