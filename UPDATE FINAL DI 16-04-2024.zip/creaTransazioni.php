<?php

    session_start();

    $server="localhost";
    $username="root";
    $password="";
    $db_name="banca";

    $connect=mysqli_connect($server,$username,$password,$db_name);

    if(!$connect){

        echo 'Errore nella connessione al database';
    }

    $IBAN_RIC=$_POST['IBAN_RIC'];
    $somma=$_POST['somma'];
    
    $IBAN_MIT=$_SESSION['IBAN_MIT'];

    $sql="INSERT INTO transazione (IBAN_RIC,somma,IBAN_MIT)
         VALUES('$IBAN_RIC','$somma','$IBAN_MIT')";

    $result=mysqli_query($connect,$sql);

    if($result){
      
        header("Location:Conto.php");
    }
    else{

       
        header("Location:Conto.php");
        echo '<script>';
        echo 'alert("Si è verificato un errore !");';
    echo '</script>';
    }



?>