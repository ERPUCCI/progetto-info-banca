<?php
    session_start();

    $servername = 'localhost';
    $name = 'root';
    $password = '';
    $nomeDB = 'progettogpo';

    $conn = mysqli_connect($servername, $name, $password, $nomeDB);

    if (!$conn) {
        die("Errore nella connessione a MySQL: " . mysqli_connect_error());
    }

    $nome = $_POST['nome'];
    $orario = $_POST['orario'];
    $indirizzo = $_POST['indirizzo'];
    $citta = $_POST['citta'];
    $descrizione = $_POST['descrizione'];
	$email = $_SESSION['email'];
    
    $nome=filter_var($nome, FILTER_SANITIZE_EMAIL);
    $orario=filter_var($orario, FILTER_SANITIZE_EMAIL);
    $indirizzo=filter_var($indirizzo, FILTER_SANITIZE_EMAIL);
    $citta=filter_var($citta, FILTER_SANITIZE_EMAIL);
    $descrizione=filter_var($descrizione, FILTER_SANITIZE_EMAIL);
    $email=filter_var($email, FILTER_SANITIZE_EMAIL);

    $query="INSERT INTO users
	(ID_bottega, email, orario,nome,indirizzo,città)
		VALUES ('', '$username', '$pw_MD5')";

	$result = mysqli_query($conn, $query);

	if ($result > 0) {
	// Accesso autorizzato
	echo "Registrazione effettuata correttamente";
	} 
	else{
	// Utente e/o password errati
	echo "Registrazione fallita";
	}
	if(!$result){
	echo "Errore";
	}
	$conn->close();

    // Utilizzo di funzione di hashing sicura (bcrypt) per la password


    
    


    mysqli_close($conn);
?>